# sdgs_9_Machine-Learning
Projek Machine learning pertemuan 10
